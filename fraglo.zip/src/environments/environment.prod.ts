export const environment = {
  production: true,
  server_url: 'https://example.com/test/test',
};

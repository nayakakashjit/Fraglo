import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppRoutingModule } from 'src/app/app-routing.module';
import { AppComponent } from 'src/app/app.component';
import { HeaderComponent, FooterComponent, NavComponent, FnfComponent } from 'src/app/shared/index';
import { SharedModule } from 'src/app/shared/shared.module';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { AuthGuard } from 'src/app/core/index';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,NavComponent, FnfComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule,HttpClientModule,FormsModule
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy},AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }

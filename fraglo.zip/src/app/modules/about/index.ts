/* ......All Cotact About Export Features....... */

export * from './pages/about/about.component'